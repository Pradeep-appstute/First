package com.masergy.iscticket.utility;

public class CommonResources {
	public static String prefixLink ="https://webservice-dev.masergy.com/webservices_mobile/rest/v1/";
//	public static String prefixLink ="https://webservice.masergy.com/webservices_mobile/rest/v1/";
}
