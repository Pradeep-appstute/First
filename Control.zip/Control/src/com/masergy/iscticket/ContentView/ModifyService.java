package com.masergy.iscticket.ContentView;

public class ModifyService {
    public String bundleId;
    public String bundleAlias;
    public String currentBandwidth;
    public String location;
}
