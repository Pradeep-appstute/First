package com.masergy.iscticket.ContentView;

import java.util.ArrayList;

//Child view for Doppler IM 
public class DopplerIM_Child {
	
	public String getchildText() {
		return childText;
	}
	public void setchildText(String childText) {
		this.childText = childText;
	}
	public String childText;
}
