package com.masergy.iscticket.ContentView;

public class Ticket {

    public String ticketId;
    public String subject;
    public String status;
    public String createDate;
    public String closeDate;
}
