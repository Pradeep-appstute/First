/** Automatically generated file. DO NOT MODIFY */
package in.appstute.androidlibrary;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}